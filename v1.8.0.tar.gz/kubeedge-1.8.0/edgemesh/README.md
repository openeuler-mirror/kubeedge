# EdgeMesh

EdgeMesh has been decoupled from edgecore and moved to [edgemesh](https://github.com/kubeedge/edgemesh).
