
# KubeEdge Installer

Click [here](https://kubeedge.io/en/docs/setup/keadm/) for detailed documentation of the KubeEdge installer.
