# Mappers

All mappers have been moved to [mappers-go](https://github.com/kubeedge/mappers-go).
