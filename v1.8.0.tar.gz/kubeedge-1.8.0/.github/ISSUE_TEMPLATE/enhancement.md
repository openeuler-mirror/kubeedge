---
name: Enhancement Request
about: Suggest an enhancement to the KubeEdge project
labels: kind/feature

---
<!-- Please only use this template for submitting enhancement requests -->

**What would you like to be added/modified**:

**Why is this needed**:
