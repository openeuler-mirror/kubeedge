package cloudconnection

//constants for cloud connection
const (
	CloudConnected    = "cloud_connected"
	CloudDisconnected = "cloud_disconnected"
)
