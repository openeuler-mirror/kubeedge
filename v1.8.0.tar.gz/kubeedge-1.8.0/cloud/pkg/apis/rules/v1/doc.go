// +k8s:deepcopy-gen=package

// +groupName=rules.kubeedge.io
package v1
