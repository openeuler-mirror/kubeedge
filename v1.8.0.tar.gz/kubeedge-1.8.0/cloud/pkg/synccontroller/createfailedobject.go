package synccontroller

// TODO: Compare the objects in K8s with the objects that have been persisted to the edge,
// If the objects fail to persisted to the edge for the first time, it will be recreated here.
func (sctl *SyncController) manageCreateFailedObject() {

}
